#pragma once

class ScreenMainMenu : public Screen
{
	void enable() override;

	void gui() override;
};
